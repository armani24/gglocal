from django.contrib import admin
from users.models import MyUser, Profile
# Register your models here.


admin.site.register(Profile)