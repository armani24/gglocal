from django.apps import AppConfig


class MinaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mina'
